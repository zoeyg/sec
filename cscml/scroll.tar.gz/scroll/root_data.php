<?php
  define('SCROLLS_LIST_ABSOLUTE_INCLUDE_ROOT', dirname(__FILE__) . "/");
  define('SCROLLS_LIST_TEMPLATES_PATH', dirname(__FILE__) . "/templates/");
  define('DISPLAY_POSTS', 0);
  define('AUTH_SECRET', "AAAAAAAA");
  require_once(SCROLLS_LIST_ABSOLUTE_INCLUDE_ROOT . "includes/classes.php");
?>
