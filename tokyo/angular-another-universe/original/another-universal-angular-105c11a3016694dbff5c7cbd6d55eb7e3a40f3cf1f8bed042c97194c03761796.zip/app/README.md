# Universal Angular App

## Memo

I run following commands:
- `ng new my-app`
- `ng add @nguniversal/express-engine` https://angular.io/guide/universal