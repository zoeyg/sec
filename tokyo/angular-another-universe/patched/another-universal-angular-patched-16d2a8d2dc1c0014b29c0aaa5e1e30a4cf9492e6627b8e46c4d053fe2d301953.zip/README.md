# Universal Angular

## Local dev

```
$ docker-compose up
```

## Note

I created the app starting with the following commands.

```
$ ng new app
$ cd app
$ ng add @nguniversal/express-engine
```
