<?php
class UserModel
{
    public string $username;
}